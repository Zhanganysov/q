package com.pr;

public class Flying implements Action{
    @Override
    public void someAction() {
        System.out.println("Flying...");
    }
}

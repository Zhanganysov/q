package com.pr;

public class Walking implements Action{
    @Override
    public void someAction() {
        System.out.println("Walking...");
    }
}

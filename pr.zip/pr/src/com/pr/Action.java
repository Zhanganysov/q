package com.pr;

public interface Action {
    public void someAction();
}

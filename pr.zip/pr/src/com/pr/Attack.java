package com.pr;

public class Attack implements Action{
    @Override
    public void someAction() {
        System.out.println("In attack...");
    }
}

package com.pr;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {                      // SAME WITH OTHER CHARACTERS
        Elves Elva = new Elves("Elve Maxim");
        System.out.println("Your character:"+Elva.name);

        Elva.setAct(new Walking());
        Elva.doAction();
        for(int i=0;i<2;i++) {
            Scanner in = new Scanner(System.in);
            System.out.print("Write Magic or Attack to unlock ablities:");
            String num = in.next();

            if (num.equals("Magic")) {
                Elva.setAct(new Flying());
                Elva.doAction();
            } else if (num.equals("Attack")) {
                Elva.setAct(new Attack());
                Elva.doAction();
            }
        }
    }
}

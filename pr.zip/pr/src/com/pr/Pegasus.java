package com.pr;

public class Pegasus {
    Action act;
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAct(Action act) {
        this.act = act;
    }
    public void doAction() {
        act.someAction();
    }

    public Pegasus(String name) {
        this.name = name;
    }
}
